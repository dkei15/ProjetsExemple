<?php
session_start();
//connect to database
$db=mysqli_connect("localhost","root","","biblio");
if(isset($_POST['login_btn']))
{
    $username=mysqli_real_escape_string($db,$_POST['username']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
   
    $sql="SELECT * FROM adherant WHERE username='$username' AND password='$password'";
    $result=mysqli_query($db,$sql);
    if(mysql_num_rows($result)==0)
    {
        $_SESSION['message']="You are now Loggged In";
        $_SESSION['username']=$username;
        header("location:home.php");
    }
   else
   {
                $_SESSION['message']="Username and Password combiation incorrect";
    }
}
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>connexion</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/connexion.css" type="text/css">
</head>
<body>
	<div id="page">	
		<div id="header">
			<?php
				if(isset($_SESSION['message']))
				{
					 echo "<div id='error_msg'>".$_SESSION['message']."</div>";
					 unset($_SESSION['message']);
				}
			?>
			
			<?php if(!isset($_SESSION['id'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
			else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; } ?>  
			<a href="inscription.php" class="contact" >S'inscrire</a>
			
			<a href="index.php" id="logo"><img src="images/logo.jpg" widtht= "250" height = "150"  alt="LOGO"> </a>
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="about.html">Espace personnel</a>
				</li>
				<li>
					<a href="product.html">Documentation</a>
				</li>
				<li>
					<a href="solutions.html">Service</a>
				</li>
				<li>
					<a href="news.html">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.html">Contact nous</a>
				</li>
			</ul>
		</div>
		<div id="contents">
			<div class="background">
				<div id="centre">
					<header>
						<h1 class ="h1">Service d'authentification</h1>
					</header>
					<div id="connexion">
						<form method="post" action="login.php">
							<section class="row">
								<label for="username"><b>Indentifiant  :</b> </label>
								<input type="text" name="username" class="textInput">
							</section>
							<section class="row">
								<label for="password"><b>Mot de passe  :</b> </label>
								<input type="password" name="password" class="textInput">
							</section>
							<section class="row-btn">
								<input  type="submit" name="login_btn" class="login" value="Se connecter"/>
							</section>
					</div>
				</div>
				<div id="inscription">
					<p>
						<a href ="inscription.php"><i class="i">vous êtes pas inscrit?<i></a>
					</p>
				</div>
			</div>
		</div>
</body>
</html>