-- phpMiniAdmin dump 1.9.170312
-- Datetime: 2017-04-06 18:31:49
-- Host: 
-- Database: Biblio

/*!40030 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

DROP TABLE IF EXISTS `Adherent`;
CREATE TABLE `Adherent` (
  `IdAdherant` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `MotDePass` varchar(45) DEFAULT NULL,
  `AdPrenom` varchar(45) NOT NULL,
  `AdNom` varchar(45) NOT NULL,
  `AdMail` varchar(45) DEFAULT NULL,
  `AdAdresse` varchar(45) DEFAULT NULL,
  `AdPaiement` date DEFAULT NULL,
  `AdAdhesion` date DEFAULT NULL,
  `AdNaissance` date DEFAULT NULL,
  `AdTel` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdAdherant`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Adherent` DISABLE KEYS */;
/*!40000 ALTER TABLE `Adherent` ENABLE KEYS */;

DROP TABLE IF EXISTS `Auteur`;
CREATE TABLE `Auteur` (
  `NomAuteur` varchar(45) DEFAULT NULL,
  `PrenomAuteur` varchar(45) DEFAULT NULL,
  `NaisAuteur` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Auteur` DISABLE KEYS */;
/*!40000 ALTER TABLE `Auteur` ENABLE KEYS */;

DROP TABLE IF EXISTS `Commande`;
CREATE TABLE `Commande` (
  `idCom` int(11) NOT NULL AUTO_INCREMENT,
  `ISBN` int(11) DEFAULT NULL,
  `Editeur` varchar(45) DEFAULT NULL,
  `NbdeCom` int(11) DEFAULT NULL,
  PRIMARY KEY (`idCom`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Commande` DISABLE KEYS */;
/*!40000 ALTER TABLE `Commande` ENABLE KEYS */;

DROP TABLE IF EXISTS `Editeur`;
CREATE TABLE `Editeur` (
  `idEdit` int(11) NOT NULL AUTO_INCREMENT,
  `NomEdit` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEdit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Editeur` DISABLE KEYS */;
/*!40000 ALTER TABLE `Editeur` ENABLE KEYS */;

DROP TABLE IF EXISTS `Evenement`;
CREATE TABLE `Evenement` (
  `NumEv` int(11) NOT NULL AUTO_INCREMENT,
  `TypeEv` varchar(45) DEFAULT NULL,
  `DateEv` date DEFAULT NULL,
  `LieuEv` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`NumEv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Evenement` DISABLE KEYS */;
/*!40000 ALTER TABLE `Evenement` ENABLE KEYS */;

DROP TABLE IF EXISTS `Exemplaire`;
CREATE TABLE `Exemplaire` (
  `NumExmp` int(11) NOT NULL AUTO_INCREMENT,
  `Cote` int(11) DEFAULT NULL,
  `EtatExmp` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`NumExmp`),
  KEY `fk_Exemplaire_Oeuvre_idx` (`Cote`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Exemplaire` DISABLE KEYS */;
/*!40000 ALTER TABLE `Exemplaire` ENABLE KEYS */;

DROP TABLE IF EXISTS `Oeuvre`;
CREATE TABLE `Oeuvre` (
  `Cote` int(11) NOT NULL AUTO_INCREMENT,
  `TitreOeuvre` varchar(45) DEFAULT NULL,
  `Date_Parution` date DEFAULT NULL,
  `IdAuteur` int(11) DEFAULT NULL,
  `PrixAchat` int(11) DEFAULT NULL,
  `DomOeuvre` varchar(45) DEFAULT NULL,
  `TypeOeuvre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Cote`)
) ENGINE=MyISAM AUTO_INCREMENT=2147483648 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Oeuvre` DISABLE KEYS */;
INSERT INTO `Oeuvre` VALUES ('445','grgrdg','2014-04-19','0','0','Littérature','Roman'),('549482','Le dessin','2017-03-14','0',NULL,'Arts','Livre'),('49846251','Homme moderne','2005-07-18','0',NULL,'Sociologie','Roman'),('85474155','On ne badine pas amour',NULL,'0',NULL,'Science','Science-fiction'),('2147483647','NAture morte',NULL,'0',NULL,'Science','Magazine'),('478522652','La lune morte avec amour',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Oeuvre` ENABLE KEYS */;

DROP TABLE IF EXISTS `Rayon`;
CREATE TABLE `Rayon` (
  `idRa` int(11) NOT NULL AUTO_INCREMENT,
  `DomaineRa` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idRa`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Rayon` DISABLE KEYS */;
/*!40000 ALTER TABLE `Rayon` ENABLE KEYS */;

DROP TABLE IF EXISTS `Reservation`;
CREATE TABLE `Reservation` (
  `IdAdherant` int(11) NOT NULL,
  `NumExmp` int(11) NOT NULL,
  `IdResr` int(11) NOT NULL AUTO_INCREMENT,
  `DateEmprunt` date DEFAULT NULL,
  `DateRetour` date DEFAULT NULL,
  PRIMARY KEY (`IdAdherant`,`NumExmp`,`IdResr`),
  KEY `fk_Reservation_Exemplaire1_idx` (`NumExmp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `Reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reservation` ENABLE KEYS */;

DROP TABLE IF EXISTS `appartient`;
CREATE TABLE `appartient` (
  `cote` int(11) NOT NULL,
  `id_Mot` int(11) NOT NULL,
  PRIMARY KEY (`cote`,`id_Mot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40000 ALTER TABLE `appartient` DISABLE KEYS */;
INSERT INTO `appartient` VALUES ('549482','5'),('49846251','2'),('85474155','1'),('478522652','1'),('478522652','7'),('2147483647','7');
/*!40000 ALTER TABLE `appartient` ENABLE KEYS */;

DROP TABLE IF EXISTS `mot_clefs`;
CREATE TABLE `mot_clefs` (
  `nom` varchar(25) NOT NULL,
  `id_Mot` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_Mot`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*!40000 ALTER TABLE `mot_clefs` DISABLE KEYS */;
INSERT INTO `mot_clefs` VALUES ('Amour','1'),('Homme','2'),('Badine','3'),('moderne','4'),('dessin','5'),('nature','6'),('morte','7');
/*!40000 ALTER TABLE `mot_clefs` ENABLE KEYS */;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;


-- phpMiniAdmin dump end
